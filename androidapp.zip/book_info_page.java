package com.example.bt;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class book_info_page extends AppCompatActivity {

    ImageView imageView;
    TextView textView;
    Button button,button2,button3,button4;

    public String book_name;


    private static final String TAG = "book_info_page";


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.book_info_page);

        Intent intent=getIntent();
        book_name= intent.getExtras().getString("title");
        final String author= intent.getExtras().getString("author");
        String rating= intent.getExtras().getString("rating");
        final String genre= intent.getExtras().getString("genre");
        final String img_url= intent.getExtras().getString("small_image_url");
        final String id= intent.getExtras().getString("id");

        Log.d(TAG,"Selected Book :"+ book_name);
        Log.d(TAG,"Author is :"+ author);
        Log.d(TAG,"Genre is :"+ genre);
        Log.d(TAG,"Rating is :"+ rating);
        Log.d(TAG,"ID is :"+ id);

        FirebaseDatabase database3= FirebaseDatabase.getInstance();
        DatabaseReference mref3= database3.getReference("Searched_authors");
        mref3.push().setValue(author);

        FirebaseDatabase database2= FirebaseDatabase.getInstance();
        DatabaseReference mref= database2.getReference("searched_books");
        mref.push().setValue(book_name);



        imageView = (ImageView) findViewById(R.id.imageView);
        Picasso.with(this).load(img_url).resize(350,500).into(imageView);

    textView=(TextView) findViewById(R.id.textView2);
    textView.setText("\nTitle\t "+book_name + "\nBy Author\t "+author + "\nGenre\t "+genre + "\nRated\t "+rating);

    button= (Button) findViewById(R.id.button2);
    button2= (Button) findViewById(R.id.button3);
    button3= (Button) findViewById(R.id.button1);
    button4= (Button) findViewById(R.id.button4);

    button.setOnClickListener(v -> {

        FirebaseDatabase database= FirebaseDatabase.getInstance();

        DatabaseReference mref2= database.getReference("books/"+book_name).child("books_count");
        mref2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Log.d( TAG,"val"+  dataSnapshot.getValue().toString());
              //  Toast.makeText(getApplicationContext(),"Hurry Up!! Only "+ dataSnapshot.getValue().toString() +" Available",Toast.LENGTH_LONG).show();

                AlertDialog.Builder alert= new AlertDialog.Builder(book_info_page.this);
                alert.setTitle("Hurry Up!");
                alert.setIcon(R.drawable.hurry);
                alert.setMessage("Only "+ dataSnapshot.getValue().toString() +" Copies Available " );
                alert.setCancelable(false);

                alert.setPositiveButton("OK", (dialog, which) -> {

                });

                AlertDialog alertDialog= alert.create();
                alertDialog.show();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    });

        button2.setOnClickListener(v -> {

            FirebaseDatabase database= FirebaseDatabase.getInstance();

            DatabaseReference mref2= database.getReference("books/"+book_name);
            mref2.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    Log.d(TAG,"wowowo" + dataSnapshot.getValue());
                    HashMap<String,Object> map= (HashMap<String, Object>) dataSnapshot.getValue();
                  /*  List<Integer> list = new ArrayList<>();
                    list.add(1);
                    list.add(2);
                    list.add(3);
                    list.add(4);
                    list.add(5);
                    Random rand= new Random();
                    int shelf=  list.get(rand.nextInt(list.size()));*/
                  //  Toast.makeText(getApplicationContext(),"Your Book Available in Section "+ map.get("genre").toString() +" and Shelf "+ map.get("shelf").toString(),Toast.LENGTH_LONG).show();

                    AlertDialog.Builder alert= new AlertDialog.Builder(book_info_page.this);
                    alert.setTitle("Book Location");
                    alert.setIcon(R.drawable.shelf);
                    alert.setMessage("Your Book Available in Section "+ map.get("genre").toString() +" and Shelf "+ map.get("shelf").toString() );
                    alert.setCancelable(false);

                    alert.setPositiveButton("Got it", (dialog, which) -> {

                    });

                    AlertDialog alertDialog= alert.create();
                    alertDialog.show();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        });

        button3.setOnClickListener(v -> {

            Toast.makeText(getApplicationContext(),"Thank You For Your Feedback !",Toast.LENGTH_LONG).show();

        });

        button4.setOnClickListener(v->{

            Intent intent1= new Intent(getApplicationContext(),searchbuk.class);
            startActivity(intent1);

            finish();

        });


    }

}
