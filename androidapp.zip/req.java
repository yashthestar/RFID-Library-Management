package com.example.bt;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class req extends AppCompatActivity {

    Button button;
    EditText editText;
    public String book_name;
    ImageView imageView;
    Animation animation;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.req);

        button= (Button) findViewById(R.id.button1);
        editText=(EditText) findViewById(R.id.p1);
        imageView=(ImageView)findViewById(R.id.i);


        button.setOnClickListener(v -> {

            book_name= editText.getText().toString().trim();
            if(book_name== null){
                Toast.makeText(getApplicationContext(),"Please Enter Valid Book Name",Toast.LENGTH_LONG).show();
            }
            else {

                animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.moveup);
                imageView.setVisibility(View.VISIBLE);
                imageView.startAnimation(animation);

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference mref = database.getReference("requested");
                mref.push().setValue(book_name);
                Toast.makeText(getApplicationContext(), "Request For " + book_name + " successful", Toast.LENGTH_LONG).show();
            }
        });


    }
}
