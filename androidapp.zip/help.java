package com.example.bt;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;

public class help extends AppCompatActivity {

    Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help);

        btn= (Button) findViewById(R.id.b);

        btn.setOnClickListener(v -> {
            AlertDialog.Builder alert= new AlertDialog.Builder(help.this);
            alert.setTitle("RFID Library Support");
            alert.setIcon(R.drawable.fback);
            alert.setMessage("Thank you for feedback. We will take action soon !" );
            alert.setCancelable(false);

            alert.setPositiveButton("OK", (dialog, which) -> {

                Intent intent= new Intent(getApplicationContext(),searchbuk.class);
                startActivity(intent);

            });

            AlertDialog alertDialog= alert.create();
            alertDialog.show();
        });
    }
}