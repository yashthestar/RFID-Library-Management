package com.example.bt;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;


public class searchbuk extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    AutoCompleteTextView ed1;
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    String book;
    ImageButton img,img5,img6,img7,img8,img9,img10,img11,img12;
    TextView v1,v2,v3,v4,v5,v6,v7,v8;
    private static final String TAG = "searchbuk";
    public ArrayList<String> titles = new ArrayList<>();
    public ArrayList<String> authors = new ArrayList<>();
    public ArrayList<String> genres = new ArrayList<>();
    public ArrayList<String> urls = new ArrayList<>();
    public ArrayList<String> ids = new ArrayList<>();
    public ArrayList<String>  suggestions= new ArrayList<>();


    public HashMap<String,String> rec_based_on_author = new HashMap<>();
    public HashMap<String,String> rec_based_on_genre = new HashMap<>();
    public HashMap<String,String> top_rated = new HashMap<>();

    public FirebaseDatabase database= FirebaseDatabase.getInstance();


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.searchbuk);


        // Navigation drawer initialization
        drawerLayout= (DrawerLayout) findViewById(R.id.drawer);

        actionBarDrawerToggle= new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);

        drawerLayout.bringToFront();
        drawerLayout.requestLayout();
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView= findViewById(R.id.design_navigation_view);
        navigationView.bringToFront();
        navigationView.requestLayout();
        navigationView.setNavigationItemSelectedListener(this);



        // Suggestions Autocomplete TextView
        FirebaseDatabase database2 = FirebaseDatabase.getInstance();
        DatabaseReference m= database2.getReference("books");
        m.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                suggestions= new ArrayList<>();
            for(DataSnapshot dataSnapshot1: dataSnapshot.getChildren()) {
                suggestions.add(dataSnapshot1.getKey());
            }
                Log.d(TAG,"lolololo "+suggestions);
                ed1= (AutoCompleteTextView) findViewById(R.id.search_field);
                ArrayAdapter adapter= new ArrayAdapter(searchbuk.this,android.R.layout.simple_list_item_1,suggestions);
                ed1.setAdapter(adapter);
                ed1.setThreshold(1);
                ed1.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        img= (ImageButton) findViewById(R.id.search_btn);


        // Recommendation using past issued history with jaccard index of top authors and top genres trending

        FirebaseAuth mauth = FirebaseAuth.getInstance();
        FirebaseUser user=mauth.getCurrentUser();
        String uid=user.getUid();
        DatabaseReference mref= database.getReference("issued_books/"+uid);

        mref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                titles=new ArrayList<>();
                authors=new ArrayList<>();
                genres=new ArrayList<>();
                urls=new ArrayList<>();
                Map<String,String> issued_books= (HashMap<String, String>) dataSnapshot.getValue();
                if(issued_books == null ){
                    Log.d(TAG,"No past History of the User !");
                }
                else{
                    Collection<String> issued = issued_books.values();
                    ArrayList<String> info = new ArrayList<String>(issued);
                 //   Log.d(TAG,"List :"+ info);

                    for(Object s : info){
                        ArrayList<String> al = (ArrayList) s;
                        titles.add(al.get(0));
                        authors.add(al.get(1));
                        genres.add(al.get(2));
                        urls.add(al.get(3));
                        ids.add(al.get(4));

                    }

                }

                Log.d(TAG,"Information of Past Issued Books"+ authors+genres+urls);

                Log.d(TAG,"Past Issued Books by this user are :"+ titles);

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        FirebaseDatabase database1= FirebaseDatabase.getInstance();
        DatabaseReference mbooks= database1.getReference("books");
        mbooks.addValueEventListener(new ValueEventListener() {

            HashMap<String,ArrayList<String>> hashMap= new HashMap<>();

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren()) {
                    if( authors.contains(ds.child("author").getValue().toString())){
                        if(!titles.contains(ds.getKey())){
                            ArrayList<String> something = new ArrayList<>();
                            something.add(ds.child("genre").getValue().toString());
                            something.add(ds.child("author").getValue().toString());
                            something.add(ds.child("average_rating").getValue().toString());
                            something.add(ds.child("small_image_url").getValue().toString());
                            something.add(ds.child("id").getValue().toString());
                            hashMap.put( ds.getKey(), something);

                            rec_based_on_author.put(ds.getKey(),ds.child("small_image_url").getValue().toString());
                        }

                    }
                }

                for(DataSnapshot ds: dataSnapshot.getChildren()) {
                    if( genres.contains(ds.child("genre").getValue().toString())){
                        if(!titles.contains(ds.getKey())){
                            ArrayList<String> something = new ArrayList<>();
                            something.add(ds.child("genre").getValue().toString());
                            something.add(ds.child("author").getValue().toString());
                            something.add(ds.child("average_rating").getValue().toString());
                            something.add(ds.child("small_image_url").getValue().toString());
                            something.add(ds.child("id").getValue().toString());
                            rec_based_on_genre.put(ds.getKey(),ds.child("small_image_url").getValue().toString() );
                            hashMap.put( ds.getKey(), something);
                        }

                    }
                }
                for(DataSnapshot ds: dataSnapshot.getChildren()) {

                    try
                    {double val= Double.parseDouble(ds.child("average_rating").getValue().toString());
                        if(val > 3.50){
                            if(!titles.contains(ds.getKey())){
                                ArrayList<String> something = new ArrayList<>();
                                something.add(ds.child("genre").getValue().toString());
                                something.add(ds.child("author").getValue().toString());
                                something.add(ds.child("average_rating").getValue().toString());
                                something.add(ds.child("small_image_url").getValue().toString());
                                something.add(ds.child("id").getValue().toString());
                                rec_based_on_genre.put(ds.getKey(),ds.child("small_image_url").getValue().toString() );
                                hashMap.put( ds.getKey(), something);
                                top_rated.put(ds.getKey(), ds.child("small_image_url").getValue().toString());
                            }
                        }}
                    catch (NumberFormatException n){
                        continue;}

                }

                Log.d(TAG,"Recommendations hashmap :"+ hashMap);
                Log.d(TAG,"Recommendations :"+ rec_based_on_author+rec_based_on_genre+top_rated);


                    Random  random = new Random();

              /*  try {
                    img1 = (ImageButton) findViewById(R.id.image1);
                    String rk1 = urls.get(r.nextInt(urls.size()));
                    Picasso.with(searchbuk.this).load(rk1).resize(100, 150).into(img1);
                    urls.remove(rk1);

                    img2 = (ImageButton) findViewById(R.id.image2);
                    String rk2 = urls.get(r.nextInt(urls.size()));
                    Picasso.with(searchbuk.this).load(rk2).resize(100, 150).into(img2);
                    urls.remove(rk2);

                    img3 = (ImageButton) findViewById(R.id.image3);
                    String rk3 = urls.get(r.nextInt(urls.size()));
                    Picasso.with(searchbuk.this).load(rk3).resize(100, 150).into(img3);
                    urls.remove(rk3);

                    img4 = (ImageButton) findViewById(R.id.image4);
                    String rk4 = urls.get(r.nextInt(urls.size()));
                    Picasso.with(searchbuk.this).load(rk4).resize(100, 150).into(img4);
                    urls.remove(rk4);
                }
                catch (IllegalArgumentException exc){} */

                try {
                    rec_based_on_author.putAll(rec_based_on_genre);
                    ArrayList<String> keys  = new ArrayList<String>(rec_based_on_author.keySet());

                    ArrayList<String> keys2  = new ArrayList<String>(top_rated.keySet());

                    img5 = (ImageButton) findViewById(R.id.image5);
                    v1= (TextView) findViewById(R.id.textView01);

                    String  randomKey = keys.get( random.nextInt(keys.size()));
                    img5.setOnClickListener(v -> {
                      //  Log.d(TAG, "dk"+ hashMap.keySet() );
                      //  Log.d(TAG, "dk"+ hashMap.values() );
                        for(String entry : hashMap.keySet()){
                            if(hashMap.get(entry).get(3).equals(rec_based_on_author.get(randomKey))){
                               Intent intent=new Intent(getApplicationContext(),book_info_page.class);
                                intent.putExtra("title",randomKey);
                                intent.putExtra("genre", hashMap.get(entry).get(0));
                                intent.putExtra("author",hashMap.get(entry).get(1));
                                intent.putExtra("rating",hashMap.get(entry).get(2) );
                                intent.putExtra("small_image_url",hashMap.get(entry).get(3));
                                intent.putExtra("id",hashMap.get(entry).get(4));
                                startActivity(intent);
                            }
                        }
                    });
                    Log.d(TAG,"Random test :"+ rec_based_on_author.get(randomKey) + randomKey);
                    keys.remove(randomKey);
                    Picasso.with(searchbuk.this).load(rec_based_on_author.get(randomKey)).resize(100, 150).into(img5);
                    v1.setText(randomKey);

                    img6 = (ImageButton) findViewById(R.id.image6);
                    v2 = (TextView) findViewById(R.id.textView02);
                    String  randomKey01 = keys.get( random.nextInt(keys.size()));
                    img6.setOnClickListener(v -> {
                        for(String entry : hashMap.keySet()){
                            if(hashMap.get(entry).get(3).equals(rec_based_on_author.get(randomKey01))){
                                Intent intent=new Intent(getApplicationContext(),book_info_page.class);
                                intent.putExtra("title",randomKey01);
                                intent.putExtra("genre", hashMap.get(entry).get(0));
                                intent.putExtra("author",hashMap.get(entry).get(1));
                                intent.putExtra("rating",hashMap.get(entry).get(2) );
                                intent.putExtra("small_image_url",hashMap.get(entry).get(3));
                                intent.putExtra("id",hashMap.get(entry).get(4));
                                startActivity(intent);
                            }
                        }
                    });
                    Log.d(TAG,"Random test :"+ rec_based_on_author.get(randomKey01) + randomKey01);
                    keys.remove(randomKey01);
                    Picasso.with(searchbuk.this).load(rec_based_on_author.get(randomKey01)).resize(100, 150).into(img6);
                    v2.setText(randomKey01);

                    img7 = (ImageButton) findViewById(R.id.image7);
                    v3= (TextView) findViewById(R.id.textView03);
                    String  randomKey02 = keys.get( random.nextInt(keys.size()));
                    img7.setOnClickListener(v -> {
                        for(String entry : hashMap.keySet()){
                            if(hashMap.get(entry).get(3).equals(rec_based_on_author.get(randomKey02))){
                                Intent intent=new Intent(getApplicationContext(),book_info_page.class);
                                intent.putExtra("title",randomKey02);
                                intent.putExtra("genre", hashMap.get(entry).get(0));
                                intent.putExtra("author",hashMap.get(entry).get(1));
                                intent.putExtra("rating",hashMap.get(entry).get(2) );
                                intent.putExtra("small_image_url",hashMap.get(entry).get(3));
                                intent.putExtra("id",hashMap.get(entry).get(4));
                                startActivity(intent);
                            }
                        }
                    });
                    Log.d(TAG,"Random test :"+ rec_based_on_author.get(randomKey02) + randomKey02);
                    keys.remove(randomKey02);
                    Picasso.with(searchbuk.this).load(rec_based_on_author.get(randomKey02)).resize(100, 150).into(img7);
                    v3.setText(randomKey02);

                    img8 = (ImageButton) findViewById(R.id.image8);
                    v4= (TextView) findViewById(R.id.textView04);
                    String  randomKey03 = keys.get( random.nextInt(keys.size()));
                    img8.setOnClickListener(v -> {
                        for(String entry : hashMap.keySet()){
                            if(hashMap.get(entry).get(3).equals(rec_based_on_author.get(randomKey03))){
                                Intent intent=new Intent(getApplicationContext(),book_info_page.class);
                                intent.putExtra("title",randomKey03);
                                intent.putExtra("genre", hashMap.get(entry).get(0));
                                intent.putExtra("author",hashMap.get(entry).get(1));
                                intent.putExtra("rating",hashMap.get(entry).get(2) );
                                intent.putExtra("small_image_url",hashMap.get(entry).get(3));
                                intent.putExtra("id",hashMap.get(entry).get(4));
                                startActivity(intent);
                            }
                        }
                    });
                    Log.d(TAG,"Random test :"+ rec_based_on_author.get(randomKey03) + randomKey03);
                    keys.remove(randomKey03);
                    Picasso.with(searchbuk.this).load(rec_based_on_author.get(randomKey03)).resize(100, 150).into(img8);
                    v4.setText(randomKey03);


                    img9 = (ImageButton) findViewById(R.id.image9);
                    v5= (TextView) findViewById(R.id.textView05);
                    String  randomKey2 = keys2.get( random.nextInt(keys2.size()));
                    img9.setOnClickListener(v -> {
                        for(String entry : hashMap.keySet()){
                            if(hashMap.get(entry).get(3).equals(top_rated.get(randomKey2))){
                                Intent intent=new Intent(getApplicationContext(),book_info_page.class);
                                intent.putExtra("title",randomKey2);
                                intent.putExtra("genre", hashMap.get(entry).get(0));
                                intent.putExtra("author",hashMap.get(entry).get(1));
                                intent.putExtra("rating",hashMap.get(entry).get(2) );
                                intent.putExtra("small_image_url",hashMap.get(entry).get(3));
                                intent.putExtra("id",hashMap.get(entry).get(4));
                                startActivity(intent);
                            }
                        }
                    });
                    Log.d(TAG,"Random test :"+ top_rated.get(randomKey2) + randomKey2);
                    keys2.remove(randomKey2);
                    Picasso.with(searchbuk.this).load(top_rated.get(randomKey2)).resize(100, 150).into(img9);
                    v5.setText(randomKey2);

                    img10 = (ImageButton) findViewById(R.id.image10);
                    v6= (TextView) findViewById(R.id.textView06);
                    String  randomKey3 = keys2.get( random.nextInt(keys2.size()));
                    img10.setOnClickListener(v -> {
                        for(String entry : hashMap.keySet()){
                            if(hashMap.get(entry).get(3).equals(top_rated.get(randomKey3))){
                                Intent intent=new Intent(getApplicationContext(),book_info_page.class);
                                intent.putExtra("title",randomKey3);
                                intent.putExtra("genre", hashMap.get(entry).get(0));
                                intent.putExtra("author",hashMap.get(entry).get(1));
                                intent.putExtra("rating",hashMap.get(entry).get(2) );
                                intent.putExtra("small_image_url",hashMap.get(entry).get(3));
                                intent.putExtra("id",hashMap.get(entry).get(4));
                                startActivity(intent);
                            }
                        }
                    });
                    Log.d(TAG,"Random test :"+ top_rated.get(randomKey3) + randomKey3);
                    keys2.remove(randomKey3);
                    Picasso.with(searchbuk.this).load(top_rated.get(randomKey3)).resize(100, 150).into(img10);
                    v6.setText(randomKey3);


                    img11 = (ImageButton) findViewById(R.id.image11);
                    v7= (TextView) findViewById(R.id.textView07);
                    String  randomKey4 = keys2.get( random.nextInt(keys2.size()));
                    img11.setOnClickListener(v -> {
                        for(String entry : hashMap.keySet()){
                            if(hashMap.get(entry).get(3).equals(top_rated.get(randomKey4))){
                                Intent intent=new Intent(getApplicationContext(),book_info_page.class);
                                intent.putExtra("title",randomKey4);
                                intent.putExtra("genre", hashMap.get(entry).get(0));
                                intent.putExtra("author",hashMap.get(entry).get(1));
                                intent.putExtra("rating",hashMap.get(entry).get(2) );
                                intent.putExtra("small_image_url",hashMap.get(entry).get(3));
                                intent.putExtra("id",hashMap.get(entry).get(4));
                                startActivity(intent);
                            }
                        }
                    });
                    Log.d(TAG,"Random test :"+ top_rated.get(randomKey4) + randomKey4);
                    keys2.remove(randomKey4);
                    Picasso.with(searchbuk.this).load(top_rated.get(randomKey4)).resize(100, 150).into(img11);
                    v7.setText(randomKey4);

                    img12 = (ImageButton) findViewById(R.id.image12);
                    v8= (TextView) findViewById(R.id.textView08);
                    String  randomKey5 = keys2.get( random.nextInt(keys2.size()));
                    img12.setOnClickListener(v -> {
                        for(String entry : hashMap.keySet()){
                            if(hashMap.get(entry).get(3).equals(top_rated.get(randomKey5))){
                                Intent intent=new Intent(getApplicationContext(),book_info_page.class);
                                intent.putExtra("title",randomKey5);
                                intent.putExtra("genre", hashMap.get(entry).get(0));
                                intent.putExtra("author",hashMap.get(entry).get(1));
                                intent.putExtra("rating",hashMap.get(entry).get(2) );
                                intent.putExtra("small_image_url",hashMap.get(entry).get(3));
                                intent.putExtra("id",hashMap.get(entry).get(4));
                                startActivity(intent);

                            }
                        }
                    });
                    Log.d(TAG,"Random test :"+ top_rated.get(randomKey5) + randomKey5);
                    keys2.remove(randomKey5);
                    Picasso.with(searchbuk.this).load(top_rated.get(randomKey5)).resize(100, 150).into(img12);
                    v8.setText(randomKey5);
                }
                catch (IllegalArgumentException ar){

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        img.setOnClickListener(v -> {

            book= ed1.getText().toString().trim();
            search_for_book(book);

        });

    }


    //@Override
/*    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }*/

   @Override
    public boolean onOptionsItemSelected(MenuItem item){
      //  int id= item.getItemId();
        if ( actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return onOptionsItemSelected(item);
    }

    //@Override
/*    public boolean onOptionsItemSelected( MenuItem item){
        if ( actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        switch (item.getItemId()) {
            case R.id.item1:
                Toast.makeText(getApplicationContext(), "My profile", Toast.LENGTH_LONG).show();
                break;
            case R.id.item2:
                Intent intent = new Intent(getApplicationContext(), help.class);
                startActivity(intent);
                // Toast.makeText(getApplicationContext(),"Help",Toast.LENGTH_LONG).show();
                break;
            case R.id.item3:
                Intent intent2 = new Intent(getApplicationContext(), req.class);
                startActivity(intent2);
                // Toast.makeText(getApplicationContext(),"Help",Toast.LENGTH_LONG).show();
                break;
        }
        DrawerLayout drawerLayout= (DrawerLayout) findViewById(R.id.drawer);
        drawerLayout.closeDrawer(GravityCompat.START);
        return super.onOptionsItemSelected(item);

    }*/

///   @Override
   /* public boolean onOptionsItemSelected(MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        switch (item.getItemId()) {
            case R.id.item1:

                Toast.makeText(getApplicationContext(), "My profile", Toast.LENGTH_LONG).show();
                return true;
            case R.id.item2:
                Intent intent = new Intent(getApplicationContext(), help.class);
                startActivity(intent);
                // Toast.makeText(getApplicationContext(),"Help",Toast.LENGTH_LONG).show();
                return true;
            case R.id.item3:
                Intent intent2 = new Intent(getApplicationContext(), req.class);
                startActivity(intent2);
                // Toast.makeText(getApplicationContext(),"Help",Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    } */


    private void search_for_book(final String book){

        if (TextUtils.isEmpty(book)){
            Toast.makeText(getApplicationContext(), "Search Field cannot be empty !", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference mref= database.getReference("books");
        mref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                try {

                    ArrayList<String> books = new ArrayList<>();
                    HashMap<String, Object> map = (HashMap<String, Object>) dataSnapshot.getValue();

                    HashMap<String,Object> map3= new HashMap<>();

                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        Log.d(TAG, "yoyoyoyo" + ds.getValue());
                        books.add(ds.getKey());
                        map3.put(ds.getKey(),ds.getValue());

                    }

                    Log.d(TAG, "map3 map3......" + map3);

                    Log.d(TAG, "buks......" + books);
                    Log.d(TAG, "buk" + book);

                    for (String i : books) {
                        HashMap<String, Object> map2 = (HashMap<String, Object>) map.get(i);
                        if (i.toLowerCase().equals(book.toLowerCase()) || i.toLowerCase().contains(book.toLowerCase())) {
                            Log.d(TAG, "map......" + map2);
                            Intent intent = new Intent(getApplicationContext(), book_info_page.class);
                            intent.putExtra("title",i);
                            intent.putExtra("genre", map2.get("genre").toString());
                            intent.putExtra("author", map2.get("author").toString());
                            intent.putExtra("rating", map2.get("average_rating").toString());
                            intent.putExtra("small_image_url", map2.get("small_image_url").toString());
                            intent.putExtra("id", map2.get("id").toString());
                            startActivity(intent);
                        }
                    }
                }
                catch (Exception e){
                   Toast.makeText(getApplicationContext(),"Book Not Found ",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(TAG,"Failed to read value.", databaseError.toException());
            }
        });

    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            //case R.id.item1:
               // Intent intent3 = new Intent(getApplicationContext(), profile.class);
                //startActivity(intent3);
              //  Toast.makeText(getApplicationContext(), "My profile", Toast.LENGTH_LONG).show();
                //break;
            case R.id.item2:
                Intent intent = new Intent(getApplicationContext(), help.class);
                startActivity(intent);
                // Toast.makeText(getApplicationContext(),"Help",Toast.LENGTH_LONG).show();
                break;
            case R.id.item3:
                Intent intent2 = new Intent(getApplicationContext(), req.class);
                startActivity(intent2);
                // Toast.makeText(getApplicationContext(),"Help",Toast.LENGTH_LONG).show();
                break;
          //  case R.id.item4:
            //    Intent intent1= new Intent(getApplicationContext(),bookshelf.class);
              //  startActivity(intent1);
                //break;
            case R.id.item5:
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference mref= database.getReference("books");
                DatabaseReference mref2= database.getReference("requested");
                ArrayList<String> all_books= new ArrayList<>();
                ArrayList<Object> req_books= new ArrayList<>();
                ArrayList<Object> available= new ArrayList<>();
                mref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            all_books.add(ds.getKey());
                        }
                        mref2.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                               for(DataSnapshot ds: dataSnapshot.getChildren()) {
                                   req_books.add(ds.getValue().toString());
                               }

                                HashSet<Object> set = new HashSet<>(req_books);
                                req_books.clear();
                                req_books.addAll(set);

                             //   Log.d(TAG,"balala"+ all_books);
                             //   Log.d(TAG,"balala"+ req_books);


                                for (String t : all_books) {
                                    if(req_books.contains(t)) {
                                        available.add(t);
                                    }
                                }

                                if(available.isEmpty()){

                                    AlertDialog.Builder alert= new AlertDialog.Builder(searchbuk.this);
                                    alert.setTitle("No New Books Available");
                                    alert.setIcon(R.drawable.unavailable);
                                    alert.setMessage("No New Books available \n Come Back later for more updates !" );
                                    alert.setCancelable(false);

                                    alert.setPositiveButton("Search for More", (dialog, which) -> {

                                    });

                                    AlertDialog alertDialog= alert.create();
                                    alertDialog.show();

                                }
                                else{
                                    Log.d(TAG,"balala"+ available);

                                    AlertDialog.Builder alert= new AlertDialog.Builder(searchbuk.this);
                                    alert.setTitle("New Books Available");
                                    alert.setIcon(R.drawable.happy);
                                    alert.setMessage("New Books Available are: \n"+ available +"\n Search your favorite book now !");
                                    alert.setCancelable(false);

                                    alert.setPositiveButton("Issue Now", (dialog, which) -> {

                                    });

                                    AlertDialog alertDialog= alert.create();
                                    alertDialog.show();
                                }

                                /*for(int a = 0; a < all_books.size(); a++){
                                    for(int b = 0; b < req_books.size(); b++){
                                        if(req_books.get(a).equals(all_books.get(b))){
                                            Log.d(TAG,"balala"+ all_books.get(b));
                                        }
                                    }
                                } */
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

                break;
            case R.id.item6:
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "RFID Library App");
                    String shareMessage= "\nLove Reading Books? \n Then you will Love this !\n\n";
                    shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID +"\n\n";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "Share via"));
                } catch(Exception e) {
                    Toast.makeText(getApplicationContext(),"Sharing unavailable",Toast.LENGTH_LONG).show();
                }
                break;


        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}
