package com.example.bt;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;


import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;



public class MainActivity extends AppCompatActivity{

    Animation animation;
    ImageView imageView;


    private static final String TAG = "Mainactivity";

    Button b1, b3;
    EditText ed1, ed2;
    FirebaseAuth auth;
    int counter = 3;

    public static final String CHANNEL_ID= "bt_app";
    private static final String CHANNEL_NAME= "BT App";
    private static final String CHANNEL_DESC= "BT notifications";


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        // Full screen display

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
       // getSupportActionBar().hide();


        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.ECLAIR_0_1){

            NotificationChannel channel= new NotificationChannel(CHANNEL_ID,CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(CHANNEL_DESC);
            NotificationManager manager= getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(task -> {

            if(task.isSuccessful()){
                String token=  task.getResult().getToken();
                Log.d(TAG,"Token is:"+ token);
                FirebaseDatabase database2= FirebaseDatabase.getInstance();
                DatabaseReference mref= database2.getReference("users");
                mref.push().setValue(token);
            }
            else{
                Log.d(TAG,"Error :"+  task.getException().getMessage());
            }

        });


        auth = FirebaseAuth.getInstance();

        b1 = (Button) findViewById(R.id.button);
        ed1 = (EditText) findViewById(R.id.editText);
        ed2 = (EditText) findViewById(R.id.editText2);
        imageView= (ImageView) findViewById(R.id.image);

        b3 = (Button) findViewById(R.id.button3);
        auth = FirebaseAuth.getInstance();



        b1.setOnClickListener(v -> {

            String email = ed1.getText().toString().trim();
            final String password = ed2.getText().toString().trim();


            animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
            imageView.setVisibility(View.VISIBLE);
            imageView.startAnimation(animation);

            // email id and password entries

            if (TextUtils.isEmpty(email)) {
                Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (TextUtils.isEmpty(password)) {
                Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.length() < 6) {
                Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
                return;
            }



            //authenticate user
            auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(MainActivity.this, task -> {
                        Toast.makeText(MainActivity.this, "createUserWithEmail:onComplete:" + task.isSuccessful(), Toast.LENGTH_SHORT).show();

                        if (!task.isSuccessful()) {
                            ed1.setError("Try Again");
                            ed2.setError("Try Again");
                            //tx1.setVisibility(View.VISIBLE);
                            //tx1.setBackgroundColor(Color.RED);
                            counter--;
                            Toast.makeText(getApplicationContext(),"Only "+counter+ " Attempsts Left !", Toast.LENGTH_LONG).show();

                            if (counter == 0) {
                                b1.setEnabled(false);
                            }
                        }
                        else {

                            Intent intent = new Intent(MainActivity.this, searchbuk.class);
                                startActivity(intent);

                                finish();
                            }
                        });
        });


        b3.setOnClickListener(v -> {

            // registration of new user

            animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
            imageView.setVisibility(View.VISIBLE);
            imageView.startAnimation(animation);

            Intent launchactivity = new Intent(MainActivity.this, register.class);
            startActivity(launchactivity);
        });



    }
}