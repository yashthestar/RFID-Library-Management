package com.example.bt;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class bookshelf extends AppCompatActivity {

    private static final String TAG = "bookshelf";
    LinearLayout Layout,Layout2;


    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.bookshelf);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        FirebaseAuth mauth = FirebaseAuth.getInstance();
        FirebaseUser user=mauth.getCurrentUser();
        String uid=user.getUid();
        DatabaseReference mref= database.getReference("issued_books/"+uid);

        Layout =(LinearLayout) findViewById(R.id.re);
        Layout2 =(LinearLayout) findViewById(R.id.re2);

        mref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<String> issued = new ArrayList<>();
                for(DataSnapshot ds: dataSnapshot.getChildren()){
                    issued= (ArrayList<String>) ds.getValue();
                        Log.d(TAG, "hihi" + issued.get(0));

                        ImageView image = new ImageView(bookshelf.this);
                        image.setLayoutParams(new android.view.ViewGroup.LayoutParams(500, 500));

                        TextView tv = new TextView(bookshelf.this);
                        tv.setText(issued.get(0));
                        tv.setTextColor(Color.parseColor("#dce0e8"));
                        tv.setTextSize(20);

                        Space space = new Space(bookshelf.this);
                        space.setLayoutParams(new android.view.ViewGroup.LayoutParams(50, 500));

                        Space space2 = new Space(bookshelf.this);
                        space2.setLayoutParams(new android.view.ViewGroup.LayoutParams(50, 20));
                        // Adds the view to the layout
                        Layout.addView(image);
                        Layout.addView(space2);
                        Layout2.addView(tv);
                        Layout2.addView(space);
                        Picasso.with(bookshelf.this).load(issued.get(3)).resize(50, 70).into(image);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}

















