# BE_Library_Mgmt_system
BE project in Pyqt4 
